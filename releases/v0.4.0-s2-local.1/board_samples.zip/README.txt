S2 board samples: 640x480, bottom-up, 24-bit.
Copy all five to a clean contiguous-file test card: only RED, GREEN, BLUE should display.
White stripe must be at TOP, black stripe at LEFT.
Yellow has planes=2; magenta overlaps its V4 DIB with pixel_offset=54. Both must be rejected.
Invalid-only test uses just the two bad files. Raw-sector scan can still discover old deleted BMPs;
use a card without previous valid BMP remnants. This tool only creates local files.
