SWNS: -0.363ns, STNS: -1.975ns.
HWNS: 0.003ns, HTNS: 0.000ns.
