import_device eagle_s20.db -package EG4S20BG256
import_db ../../TD_project/demo_Runs/phy_1/demo_pr.db
write_verilog s3_local2_routed_debug.v
exit

