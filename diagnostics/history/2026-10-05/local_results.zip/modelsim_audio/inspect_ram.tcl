import_device eagle_s20.db -package EG4S20BG256
import_db ../../TD_project/demo_Runs/phy_1/demo_pr.db
puts [list_property [get_cells {auto_created_cwc1/wrapper_cwc_top/U_cwc_ram/ramread0_syn_5}]]
exit
