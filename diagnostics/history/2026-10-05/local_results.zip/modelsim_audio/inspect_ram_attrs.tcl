import_device eagle_s20.db -package EG4S20BG256
import_db ../../TD_project/demo_Runs/phy_1/demo_pr.db
set c [get_cells {auto_created_cwc1/wrapper_cwc_top/U_cwc_ram/ramread0_syn_5}]
foreach p {ATTRIBUTES READBACK RAM_DEBUG IS_DEBUGGABLE} { puts "$p = [get_property $p $c]" }
exit
