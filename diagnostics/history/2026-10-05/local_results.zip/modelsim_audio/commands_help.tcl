help
exit
